import {e,U,icon,link} from './templates.mjs';

// Curated and dated source material, with no unsourced personal promises.
// Current facts: teamhodnett.com (2026 biography).
// Historical credentials: teamhodnettluxury.com/about and recognition archive.
export function renderAbout({recognition}){
 const badges=recognition.images.slice(0,4);
 const badgeCards=badges.map((image,i)=>`
  <figure class="about-award-card"><div class="about-award-card__figure"><img src="${U(image.src)}" loading="lazy" width="180" height="130" alt="${e(image.alt)}"></div>
  <figcaption><span>0${i+1} / RECOGNITION</span>${e(image.alt)}</figcaption></figure>
 `).join('');
 const serviceCards=[
  ['01','Luxury representation','Distinctive residences, estate properties and tailored marketing for luxury buyers and sellers.'],
  ['02','New construction','Experience working with builders and developers throughout North Texas.'],
  ['03','Waterfront expertise','A focus on waterfront properties, including the Eagle Mountain Lake area.'],
  ['04','Relocation','Local guidance for buyers moving to the Dallas–Fort Worth area.'],
  ['05','Strategic presentation','Property preparation, professional imagery, digital marketing and targeted exposure.'],
  ['06','Residential & investment','Representation spanning established homes, land and investment-oriented properties.']
 ].map(([n,title,description])=>`
  <article class="about-service-card"><span>${n} / EXPERTISE</span><h3>${e(title)}</h3><p>${e(description)}</p></article>
 `).join('');
 return `
 <div class="about-atrezzo">
  <section class="about-hero" aria-labelledby="about-hero-heading">
   <div class="about-hero__photo"><img src="${U('assets/editorial/sharon.webp')}" width="1440" height="2159" alt="Atrezzo Luxury, luxury real estate professional in Southlake, Texas"></div>
   <div class="about-hero__copy">
    <span class="about-kicker">ATREZZO LUXURY <i></i> SOUTHLAKE, TEXAS</span>
    <h1 id="about-hero-heading">Meet<br><em>the advisor.</em></h1>
    <p class="about-hero__lead">Verified business biography or editorial content to be supplied before launch.</p>
    <p>Verified business biography or editorial content to be supplied before launch.</p>
    <a class="about-text-link" href="#sharon-perspective">Discover her story ${icon('arrow')}</a>
    <div class="about-hero__sign"><span>ATREZZO LUXURY</span><span>LUXURY REAL ESTATE SPECIALIST</span></div>
   </div>
   <div class="about-hero__index" aria-hidden="true">01 / A PERSONAL PERSPECTIVE</div>
  </section>

  <section id="sharon-perspective" class="about-perspective wrap" aria-labelledby="about-perspective-title">
   <div class="about-section-marker">01 <span></span> HER STORY</div>
   <div class="about-perspective__main">
    <h2 id="about-perspective-title">A career shaped by<br><em>relationships.</em></h2>
    <div class="about-perspective__columns">
     <p>Verified business biography or editorial content to be supplied before launch.</p>
     <p>Verified business biography or editorial content to be supplied before launch.</p>
    </div>
    <blockquote>Approved advisor quotation goes here.<cite>— Attribution pending</cite></blockquote>
   </div>
  </section>

  <section class="about-record" aria-label="Career highlights">
   <div class="about-record__lead">
    <div class="about-section-marker">02 <span></span> THE RECORD</div>
    <h2>Experience you can<br>build on.</h2>
    <p>Verified business biography or editorial content to be supplied before launch.</p>
   </div>
   <div class="about-record__stats">
    <div class="about-stat"><strong>—<span>years</span></strong><p>Verified business biography or editorial content to be supplied before launch.</p></div>
    <div class="about-stat"><strong>—<span>volume</span></strong><p>Verified business biography or editorial content to be supplied before launch.</p></div>
    <div class="about-stat"><strong>—<span>ranking</span></strong><p>Verified business biography or editorial content to be supplied before launch.</p></div>
   </div>
  </section>

  <section class="about-expertise wrap" aria-labelledby="about-expertise-heading">
   <div class="about-expertise__intro">
    <div class="about-section-marker">03 <span></span> EXPERTISE</div>
    <h2 id="about-expertise-heading">A considered approach.<br><em>For every move.</em></h2>
    <p>Verified business biography or editorial content to be supplied before launch.</p>
   </div>
   <div class="about-expertise__grid">${serviceCards}</div>
   <div class="about-credentials">
    <div><span>PROFESSIONAL DESIGNATIONS</span><h3>Specialized knowledge. Personal service.</h3></div>
    <p>Verified business biography or editorial content to be supplied before launch.</p>
   </div>
  </section>

  <section class="about-media" aria-labelledby="about-media-heading">
   <div class="about-media__image"><img src="${U('assets/editorial/sharon-media-perspective-2026.png')}" width="1254" height="1254" loading="lazy" decoding="async" alt="Atrezzo Luxury seated in a black blazer, smiling toward the camera"></div>
   <div class="about-media__copy">
    <div class="about-section-marker">04 <span></span> MEDIA &amp; PERSPECTIVE</div>
    <h2 id="about-media-heading">An experienced<br><em>voice in real estate.</em></h2>
    <p>Verified business biography or editorial content to be supplied before launch.</p>
    <p>Verified business biography or editorial content to be supplied before launch.</p>
    ${link('vlog/','Explore her film archive')}
   </div>
  </section>

  <section class="about-recognition wrap" aria-labelledby="about-awards-heading">
   <div class="about-recognition__heading">
    <div><div class="about-section-marker">05 <span></span> AWARDS &amp; RECOGNITION</div><h2 id="about-awards-heading">A record of<br><em>recognition.</em></h2></div>
    <div><p>Verified business biography or editorial content to be supplied before launch.</p>${link('awards/','View the complete archive')}</div>
   </div>
   <div class="about-recognition__grid">${badgeCards}</div>
  </section>

  <section class="about-personal" aria-labelledby="about-personal-heading">
   <div class="about-personal__lead"><div class="about-section-marker">06 <span></span> BEYOND REAL ESTATE</div><h2 id="about-personal-heading">More than a profession.<br><em>A personal story.</em></h2></div>
   <div class="about-personal__body">
    <p>Verified business biography or editorial content to be supplied before launch.</p>
    <p>Verified business biography or editorial content to be supplied before launch.</p>
   </div>
   <div class="about-personal__footer">ROOTED IN NORTH TEXAS <span></span> CONNECTED BY TRUST</div>
  </section>

  <section class="about-close" aria-labelledby="about-close-heading">
   <img src="${U('assets/editorial/landscape.webp')}" loading="lazy" alt="" aria-hidden="true">
   <div class="about-close__content">
    <span class="about-kicker">ATREZZO LUXURY / LET'S CONNECT</span>
    <h2 id="about-close-heading">Your next move<br>deserves perspective.</h2>
    <p>Verified business biography or editorial content to be supplied before launch.</p>
    <div class="about-close__actions"><a href="${U('contact/')}" class="about-text-link">Call [Phone] ${icon('arrow')}</a><a href="${U('contact/')}" class="about-text-link">Email the advisor ${icon('arrow')}</a></div>
   </div>
  </section>
  <p class="about-source-note wrap">Profile references: <a href="${U('contact/')}" target="_blank" rel="noopener noreferrer">the advisor’s official 2026 biography</a>, <a href="${U('contact/')}" target="_blank" rel="noopener noreferrer">her archived profile</a>, and Atrezzo Luxury’s historical recognition collection. Dated honors and cumulative figures should not be read as current property availability or future performance guarantees.</p>
 </div>
 `;
}
